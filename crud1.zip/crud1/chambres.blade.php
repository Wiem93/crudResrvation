@extends('layouts.appadmin')
@section('content')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Chambres</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Dash</a></li>
              <li class="breadcrumb-item active">Chambres</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
      <div class="col-md-2 col-sm-3">
        <a href="{{URL::to('/admin/pages/gestion/chambre_add')}}" class="btn btn-primary">Ajouter une chambre</a>
    </div>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Chambres</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
          </div>
        </div>
        <div class="card-body p-0">

                  @if (count($chambres )>0)
                  <table class="table table-striped projects">
                    <thead>
                        <tr>
                            <th style="width: 1%">
                                ID
                            </th>
                            <th style="width: 20%">
                              Type de Chambre
                            </th>
                            <th style="width: 20%">
                              Description de Chambre
                            </th>
                            <th style="width: 30%">
                              URL de l'image
                            </th>
                            <th style="width: 20%">
                              Prix
                            </th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                @foreach($chambres  as $chambre)
                <tr>
                    <td>{{$chambre->id}}</td>
                    <td>{{$chambre->chtype }}</td>
                    <td>{{$chambre->chdesc }}</td>
                    <td>{{$chambre->churl }}</td>
                    <td>{{$chambre->chprix }}</td>
                    <td class="project-actions text-right">
                        <a class="btn btn-info btn-sm" href="/editer-chambre/{{$chambre->id}}">
                            <i class="fas fa-pencil-alt">
                            </i>
                        </a>
                        <a class="btn btn-danger btn-sm" href="/supprimer-chambre/{{$chambre->id}}">
                            <i class="fas fa-trash">
                            </i>
                        </a>
                    </td>

                </tr>
                @endforeach
                @else
                <p>la liste est vide</p>
                @endif
              </tbody>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
@endsection
