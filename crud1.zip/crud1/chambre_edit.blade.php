@extends('layouts.appadmin')
@section('content')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ajouter de chambres</h1>

                @if(isset($msg))
                <p style="background-color:grey;width:100%;padding:2vw;color:white;text-align:center;">
                {{$msg}}
                </p>
                @endif

          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Dash</a></li>
              <li class="breadcrumb-item active">chambres</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">General</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                  <i class="fas fa-minus"></i></button>
              </div>
            </div>
            <form action="/chambre_edit/{{$chambre[0]->id}}" method="POST" enctype="multipart/form-data">
                {{-- @csrf --}}
            <div class="card-body">
              <div class="form-group">

                <label for="inputName">Type de Chambre</label>
                <input type="text" name="chtype" id="chtype" class="form-control" value="{{$chambre[0]->chtype}}">

              </div>
              <div class="form-group">
                <label for="inputDescription"> Description de Chambre</label>
                <textarea id="chdesc" name="chdesc" class="form-control" rows="4">{{$chambre[0]->chdesc}}</textarea>
              </div>

              <div class="form-group">
                  <img style="width:10vw ;" src="/churl/{{$chambre[0]->churl}}" /><br>
                <div class="input-group">
                  <div class="custom-file">
                    <input type="file" name="churl" class="custom-file-input" id="churl">
                    <label class="custom-file-label" for="exampleInputFile">Changer image</label>
                  </div>

                </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <div class="col-md-6">
          <div class="card card-secondary">
            <div class="card-header">
              <h3 class="card-title">Budget</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                  <i class="fas fa-minus"></i></button>
              </div>
            </div>
            <div class="card-body">

              <div class="form-group">
                <label for="inputSpentBudget">Prix</label>
                <input type="number" name="chprix" id="chprix" class="form-control" value="{{$chambre[0]->chprix}}">
              </div>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <a href="#" class="btn btn-secondary">Annuler</a>
          <input type="submit" value="Ajouter chambre" class="btn btn-success float-right">
        </div>
      </div>
    </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>

@endsection
